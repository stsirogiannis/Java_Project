package gr.unipi.gui;
import gr.unipi.core.Enrollment;
import gr.unipi.core.User;
import gr.unipi.core.Athlete;
import gr.unipi.core.Coach;
import gr.unipi.core.Sport;



import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent; nh

public class AthleteManagementSceneCreator extends SceneCreator implements EventHandler<MouseEvent> {



}
