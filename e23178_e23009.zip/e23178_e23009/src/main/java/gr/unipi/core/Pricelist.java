package gr.unipi.core;

public interface Pricelist {
	double calculateTotalPrice();

	
}
